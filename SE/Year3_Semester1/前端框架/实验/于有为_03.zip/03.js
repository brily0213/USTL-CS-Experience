// This is the custom JavaScript file referenced by index.html. You will notice
// that this file is currently empty. By adding code to this empty file and
// then viewing index.html in a browser, you can experiment with the example
// page or follow along with the examples in the book.
//
// See README.txt for more information.
//1.在样式转换器按钮上启用悬停效果，使得背景变为#afa
$(document).ready(function() {
      $('#switcher').hover(function() {
        $(this).addClass('hover');
      }, function() {
        $(this).removeClass('hover');
      });
    //2.单击样式转换器时，能够折叠和扩展
      var toggleSwitcher = function(event) {
        if (!$(event.target).is('button')) {
          $('#switcher button').toggleClass('hidden');
        }
      };
      $('#switcher').on('click', toggleSwitcher);
    //3.模拟一次单击，以便开始时处以折叠状态
      $('#switcher').click();
    //4.
      var setBodyClass = function(className) {
        $('body').removeClass().addClass(className);
        $('#switcher button').removeClass('selected');
        $('#switcher-' + className).addClass('selected');
        $('#switcher').unbind('click', toggleSwitcher);
        if (className == 'default') {
          $('#switcher').on('click', toggleSwitcher);
        }
      };
     
      $('#switcher-default').addClass('selected');
    
      var triggers = {
        D: 'default',
        N: 'narrow',
        L: 'large'
      };
    
      $('#switcher').click(function(event) {
        if ($(event.target).is('button')) {
          var bodyClass = event.target.id.split('-')[1];
          setBodyClass(bodyClass);
        }
      });
    
      $(document).keyup(function(event) {
        var key = String.fromCharCode(event.keyCode);
        if (key in triggers) {
          setBodyClass(triggers[key]);
        }
      });
    });
    