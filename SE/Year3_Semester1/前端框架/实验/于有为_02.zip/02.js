// This is the custom JavaScript file referenced by index.html. You will notice
// that this file is currently empty. By adding code to this empty file and
// then viewing index.html in a browser, you can experiment with the example
// page or follow along with the examples in the book.
//
// See README.txt for more information.
$(document).ready(function() {
	    $('#selected-plays > li').addClass('horizontal');
	    $(":header").css("background-color","#bbffaa");
	    $("#selected-plays ul li:even").css("background-color","red");
	    $('#selected-plays li:not(.horizontal)').addClass('sub-level');
	    $("td:contains(Hamlet)").css("background-color","#bbffaa");
	    $("li:has(.sub-level)").css("background-color","#bbffaa ");
	    $("td:empty").css("background-color","#bbffaa");
	    $("div:hidden").show().css("background-color","#00aabb");
	    $('a[href^="mailto:"]').addClass('mailto');
	    $('a[href$=".pdf"]').addClass('pdflink');
	    $('a[href^="http"][href*="henry"]').addClass('henrylink');
	    $("tr:even").addClass("alt");
	    $("td:contains(Henry)").addClass("highlight");
	    $('a').filter(function() {
	      return this.hostname && this.hostname != location.hostname;
	    }).addClass('external');
	    $("div").css("background","#c8ebcc").filter("#container2")
	    .css("border","2px solid red");
	    $("#container2 table:first tr td:last-child").addClass("year");
	})