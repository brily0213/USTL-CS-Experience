package com.example;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.*;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class E
 */
public class E extends HttpServlet {
	private static final long serialVersionUID = 1L;
    Map<String,Entry> entries=new HashMap<String,Entry>();  
    public E() {
        super();
        entries.put("EAVESDROP"
        		, new Entry("v.i."
        				,"Secretly to overhear a catalogue of the crimes and vices of another or yourself."
        				,new String[]{
		        			"A lady with one of her ears applied",
		        		      "To an open keyhole heard, inside,",
		        		      "Two female gossips in converse free &mdash;",
		        		      "The subject engaging them was she.",
		        		      "\"I think,\" said one, \"and my husband thinks",
		        		      "That she\'s a prying, inquisitive minx!\"",
		        		      "As soon as no more of it she could hear",
		        		      "The lady, indignant, removed her ear.",
		        		      "\"I will not stay,\" she said, with a pout,",
		        		      "\"To hear my character lied about!\"",
        				}
        				,"Gopete Sherany"
        		));
        entries.put("EDIBLE"
        		, new Entry("adj."
        				,"Good to eat, and wholesome to digest, as a worm to a toad, a toad to a snake, a snake to a pig, a pig to a man, and a man to a worm."
        		));
        entries.put("EDUCATION"
        		, new Entry("n."
        				,"The art of orally persuading fools that white is the color that it appears to be.  It includes the gift of making any color appear white."
        		));
        entries.put("ELOQUENCE"
        		, new Entry("n."
        				,"That which discloses to the wise and disguises from the foolish their lack of understanding."
        		));
        entries.put("ELYSIUM"
        		, new Entry("n."
        				,"An imaginary delightful country which the ancients foolishly believed to be inhabited by the spirits of the good.  This ridiculous and mischievous fable was swept off the face of the earth by the early Christians &mdash; may their souls be happy in Heaven!"
        				));
        entries.put("EMANCIPATION"
        		, new Entry("n."
        				,"A bondman\'s change from the tyranny of another to the despotism of himself."
        				,new String[]{
        						 "He was a slave:  at word he went and came; ",
        					      "His iron collar cut him to the bone.",
        					      "Then Liberty erased his owner\'s name,",
        					      "Tightened the rivets and inscribed his own.",
        				}
        				,"G.J."
        				));
        entries.put("EMOTION"
        		, new Entry("n."
        				,"A prostrating disease caused by a determination of the heart to the head.  It is sometimes accompanied by a copious discharge of hydrated chloride of sodium from the eyes."
        				));
        entries.put("ENVELOPE"
        		, new Entry("n."
        				,"The coffin of a document; the scabbard of a bill; the husk of a remittance; the bed-gown of a love-letter."
        				));
        entries.put("ENVY"
        		, new Entry("n."
        				,"Emulation adapted to the meanest capacity."
        				));
        entries.put("EPITAPH"
        		, new Entry("n."
        				,"An inscription on a tomb, showing that virtues acquired by death have a retroactive effect.Following is a touching example:"
        				,new String[]{
        						"Here lie the bones of Parson Platt,",
        					      "Wise, pious, humble and all that,",
        					      "Who showed us life as all should live it;",
        					      "Let that be said &mdash; and God forgive it!",
        				}
        				
        				));
        entries.put("EVANGELIST"
        		, new Entry("n."
        				,"A bearer of good tidings, particularly (in a religious sense) such as assure us of our own salvation and the damnation of our neighbors."
        				));
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out= response.getWriter();
		String term=request.getParameter("term");
		if(term==null){
			out.print("<div>Sorry, your term was not found.</div>");
		}else{
			term=term.toUpperCase();
			if(entries.get(term)==null){
				out.print("<div>Sorry, your term was not found.</div>");
			}else{
				out.print(buildEntry(term,entries.get(term)));
			}
		}
	}

	private String buildEntry(String term, Entry entry) {
		String html="";
		html = "<div class='entry'>";
		  html += "<h3 class=\"term\">";
		  html += term;
		  html += "</h3>";

		  html += "<div class=\"part\">";
		  html += entry.part;
		  html += "</div>";

		  html += "<div class=\"definition\">";
		  html += entry.definition;
		  if (entry.quote.length>0) {
		    html += "<div class=\"quote\">";
		    for (String line:entry.quote) {
		      html += "<div class=\"quote-line\">"+ line +"</div>";
		    }
		    if (entry.author!=null) {
		      html += "<div class=\"quote-author\">";
		      html += entry.author +"</div>";
		    }
		    html += "</div>";
		  }
		  html += "</div>";
		  html += "</div>";

		  return html;
	}

}
class Entry{
	String part;
	String definition;
	String[] quote=new String[0];
	String author;
	public Entry(String part, String definition, String[] quote,
			String author) {
		super();
		this.part = part;
		this.definition = definition;
		this.quote = quote;
		this.author = author;
	}
	
	public Entry(String part, String definition, String[] quote) {
		super();
		this.part = part;
		this.definition = definition;
		this.quote = quote;
	}

	public Entry(String part, String definition) {
		super();
		this.part = part;
		this.definition = definition;
	}

	public Entry() {
		super();
	}
	
}
